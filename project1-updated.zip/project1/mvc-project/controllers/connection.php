<?php

$host = "localhost:3306";
$database = "lesmy74_mvcdb";
$username = "lesmy74mvc";
$password = "ka!65c9F6";



// $host = "localhost:3306";
// $database = "lesmy74_project";
// $username = "lesmy74_project";
// $password = "O60qy26^a";

?>