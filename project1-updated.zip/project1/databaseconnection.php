<?php

// $host = "localhost:3306";
// $dbname = "lesmy_resources";
// $user = "lesmy_resources";
// $password = "*23wCc0z9";


// new database connection\
$host = "localhost:3306";
$dbname = "lesmy74_awp";
$user = "lesmy74";
$password = "3#BO%V#R61l8#Evb";

?>